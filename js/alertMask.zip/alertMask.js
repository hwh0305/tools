// 初始化样式和要用到的层
var initText = 
"<style type='text/css'>" +
"<!--" + 
"#ALERTMASK {" +
"	position: absolute;" +
"	border-top: thin solid #A9CDEF;" +
"	border-left: thin solid #A9CDEF;" +
"	border-right: medium outset #A9CDEF;" +
"	border-bottom: medium outset #A9CDEF;" +
"	z-index: 1000;" +
"	height: 300px;" +
"	width: 500px;" +
"	font-size: small;" +
"}" +
"#TITLEVIEW {" +
"	height: 26px;" +
"	width: 100%;" +
"	cursor:default;" +
"	vertical-align:middle;" +
"	background-image: url(alertMaskImage/title.jpg);" +
"	background-repeat: repeat-x;" +
"	background-color: white;" +
"	z-index: 1001;" +
"}" +
"#TEXTVIEW {" +
"	width: 100%;" +
"	overflow: auto;" +
"	background-color: white;" +
"	z-index: 1001;" +
"}" +
"#FRMVIEW {" +
"	width: 100%;" +
"	z-index: 1001;" +
"	background-color: white;" +
"}" +
".IMGBUTTON {" +
"	cursor: pointer;" +
"	float: right;" +
"	margin-bottom: 5px;" +
"	margin-right: 3px;" +
"	margin-top: 5px;" +
"	z-index: 1000;" +
"}" +
"#TITLETEXT {" +
"	float: left;" +
"	margin-top: 5px;" +
"	margin-left: 10px;" +
"	margin-bottom: 5px;" +
"	z-index: 1000;" +
"}" +
"//-->" +
"</style>" +
"<div id='ALERTMASK' align='center' style='display: none;'>" +
"	<div id='TITLEVIEW' align='right' onmousedown='catchMask(event)'" +
"		onmouseup='releaseMask(event)' ondblclick='maskChange(event)'>" +
"		<div id='TITLETEXT'></div>" +
"		<img class='IMGBUTTON' onclick='maskClose()'" +
"			src='alertMaskImage/close.gif' />" +
"		<img id='ORGVIEW' class='IMGBUTTON' onclick='maskOrg()'" +
"			src='alertMaskImage/restore.gif' />" +
"		<img id='MAXVIEW' class='IMGBUTTON' onclick='maskMax()'" +
"			src='alertMaskImage/max.gif' />" +
"	</div>" +
"	<div id='TEXTVIEW'></div>" +
"	<iframe width='100%' scrolling='auto' id='FRMVIEW' frameborder='0'></iframe>" +
"</div>";

// 原始y轴
var srcTop = "";
// 原始经轴
var srcLeft = "";
// 原始高度
var srcHeight = 300;
// 原始宽度
var srcWidth = 500;
// 原始状态
var curState = "org";
// 是否使用iframe
var srcIsUrl = true;
// 是否捕获到移动事件
var bIsCatchMask = false;
// 鼠标位置X轴
var dragClickX = 0;
// 鼠标位置Y轴
var dragClickY = 0;

document.write(initText);
var baseLayer = document.getElementById("ALERTMASK");
var fram = document.getElementById("FRMVIEW");
var org = document.getElementById("ORGVIEW");
var max = document.getElementById("MAXVIEW");
var text = document.getElementById("TEXTVIEW");
var title = document.getElementById("TITLETEXT");
var titleView = document.getElementById("TITLEVIEW");

// 关闭层
function maskClose() {
	fram.src = "";
	text.innerHTML = "";
	if (document.all) {
		var iframeShim = document.getElementById("_hvrShm");
		iframeShim.style.display="none";
	}
	baseLayer.style.display = "none";
	
	srcTop = "";
	srcLeft = "";
	srcHeight = 300;
	srcWidth = 500;
	curState = "org";
	srcIsUrl = true;
}

// 弹出层
function maskAlert(body, isUrl, event, capital) {
	if (capital != undefined)
		title.innerHTML = capital;
	org.style.display = "none";
	max.style.display = "";
	srcIsUrl = isUrl == null ? true : isUrl;
	if (srcIsUrl) {
		fram.src = body;
		fram.style.display = "";
		text.style.display = "none";
	} else {
		text.innerHTML = body;
		fram.style.display = "none";
		text.style.display = "";
	}
	curState = "org";
	if (event == undefined) {
		srcTop = (window.screen.availHeight - srcHeight) / 2;
		srcLeft = (window.document.body.clientWidth - srcWidth) / 2;
	} else {
		srcTop = event.clientY;
		srcLeft = event.clientX;
		if ((event.clientY + srcHeight) > window.screen.height) {
			srcTop = event.clientY - srcHeight;
		} 
		if ((event.clientX + srcWidth) > window.screen.width) {
			srcLeft = event.clientX - srcWidth;
		}
		
	}
	baseLayer.style.top = srcTop + "px";
	baseLayer.style.left = srcLeft + "px";
	baseLayer.style.width = srcWidth + "px";
	baseLayer.style.height = srcHeight + "px";
	if (srcIsUrl) {
		fram.height = srcHeight - 26 + "px";
	} else {
		text.style.height = srcHeight - 26 + "px";
	}
	if (document.all) { 
		baseLayer.insertAdjacentHTML("afterEnd", 
			'<IFRAME style="position: absolute;z-index:0;" src="javascript:false;" frameBorder="0" scrolling="no" id="_hvrShm" />'); 
		var iframeShim = document.getElementById("_hvrShm");
		iframeShim.style.display="none";
		baseLayer.onmove=function(obj){
			iframeShim.style.top = this.style.top; 
			iframeShim.style.left = this.style.left 
			iframeShim.style.width = this.offsetWidth; 
			iframeShim.style.height = this.offsetHeight; 
			iframeShim.style.display="";
		}
	}
	baseLayer.style.display = "";
}

// 最大化
function maskMax() {
	org.style.display = "";
	max.style.display = "none";
	if (srcIsUrl) {
		fram.style.display = "";
		text.style.display = "none";
	} else {
		fram.style.display = "none";
		text.style.display = "";
	}
	curState = "max";
	baseLayer.style.top = "0px";
	baseLayer.style.left = "0px";
	baseLayer.style.width = window.screen.width - 24 + "px";
	baseLayer.style.height = window.screen.height + "px";
	if (srcIsUrl) {
		fram.height = window.screen.height - 26 + "px";
	} else {
		text.style.height = window.screen.height - 26 + "px";
	}
	baseLayer.style.display = "";
}

// 还原
function maskOrg() {
	org.style.display = "none";
	max.style.display = "";
	if (srcIsUrl) {
		fram.style.display = "";
		text.style.display = "none";
	} else {
		fram.style.display = "none";
		text.style.display = "";
	}
	curState = "org";
	baseLayer.style.top = srcTop + "px";
	baseLayer.style.left = srcLeft + "px";
	baseLayer.style.width = srcWidth + "px";
	baseLayer.style.height = srcHeight + "px";
	if (srcIsUrl) {
		fram.height = srcHeight - 26 + "px";
	} else {
		text.style.height = srcHeight - 26 + "px"; 
	}
	baseLayer.style.display = "";
}

// 双击层标题时，层状态变化
function maskChange(event) {
	var obj = event.target;
	if (obj == undefined)
		obj = event.srcElement;
	if (obj == titleView) {
		if (curState == "max") {
			maskOrg();
		} else {
			maskMax();
		}
	}
}

// 捕获到移动事件
function catchMask(event) {
	if (curState == "org") 
		bIsCatchMask = true;
	var x = event.clientX + document.body.scrollLeft;
	var y = event.clientY + document.body.scrollTop;
	dragClickX = x - srcLeft;
	dragClickY = y - srcTop;
	document.onmousemove = moveMask;
	if(titleView.setCapture)
		titleView.setCapture();
	else if(window.captureEvents)
		window.captureEvents(Event.MOUSEUP | EVENT.MOUSEMOVE);
}

// 释放捕获事件
function releaseMask(event) {
	bIsCatchMask = false;
	document.onmousemove = null;
	if(titleView.releaseCapture)
		titleView.releaseCapture();
	else if(window.releaseEvents)
		window.releaseEvents(Event.MOUSEUP | EVENT.MOUSEMOVE);
}

// 移动层
function moveMask(e) {
	if(bIsCatchMask) {
		if (!e)
			e = window.event;
		srcTop = e.clientY + document.body.scrollTop - dragClickY;
		srcLeft = e.clientX + document.body.scrollLeft - dragClickX;
		baseLayer.style.left = srcLeft + "px";
		baseLayer.style.top = srcTop + "px";
	}
}
